# Sophia8 Assembler (`s8asm`)
Programmer’s Reference Manual (Assembler + ISA + Standard Libraries)
====================================================================

This document describes the **Sophia8 assembler language**, the `s8asm` assembler tool,
the Sophia8 VM instruction set as implemented by `sophia8`, and the provided
standard libraries (`kernel.s8`, `mem.s8`, `fmt.s8`, `str.s8`, `rng.s8`, plus newer modular libs: `ctype.s8`, `u16.s8`, `int16.s8`, `conv.s8`, `line.s8`, `parse.s8`, `stdio_console.s8`).

Note: `cli.s8` and `text.s8` remain for backward compatibility, but their responsibilities are now split into `line.s8` + `parse.s8` and superseded by `ctype.s8`/`conv.s8` where appropriate.

This is written as a *working engineer’s reference*, not marketing material.
Everything here is explicit. Anything not described should be considered undefined.

---

## 1. Overview

Sophia8 is a deliberately small virtual 8‑bit computer.

- **Data width:** 8 bit
- **Address width:** 16 bit (0x0000–0xFFFF)
- **Memory model:** unified (code and data share memory)
- **Execution model:** single-threaded, deterministic
- **Endianness:** big-endian for 16‑bit values

The assembler produces a **full memory image**, not relocatable object files.

---

## 2. The `s8asm` assembler

### Invocation

```bash
s8asm input.s8 -o output.bin
```

- `input.s8` — main assembly file
- `output.bin` — raw binary memory image

If `-o` is omitted, the assembler writes `sophia8_image.bin` in the current directory.

### What the assembler does

1. Preprocesses `.include` (recursively) as *textual include*
2. Builds a single global label namespace
3. Applies `.org` directives (absolute placement)
4. Reserves addresses `0x0000..0x0002` for an implicit entry stub
5. Emits an implicit `JMP <entry>` at `0x0000`
6. Outputs a full binary image of size `0xFFFF` bytes

### Debugging outputs (generated automatically)

When you assemble to `output.bin`, `s8asm` also writes two **sidecar** files next to it:

- `output.pre.s8` — the **fully preprocessed** source with all `.include` expanded into one file.
  - Each original source line is preceded by an origin marker comment: `;@ <file>:<line>`
  - The original line text is preserved, so you can re-assemble the `.pre.s8` file if needed.

- `output.deb` — a **debug map** that records how emitted bytes relate to source locations.
  - Contains both CODE and DATA records, emitted address, length, bytes, and `file:line: original source line`.
  - Used by the Sophia8 VM to map **breakpoints** (source file + line) to runtime addresses.

### Errors are strict

The assembler **fails hard** on:

- Undefined labels
- Duplicate labels
- Invalid instructions
- Invalid operands
- Multiple entry `.org`
- Overlapping memory regions
- Non-ASCII strings
- Include cycles
- Multiple inclusion of the same include file (include-once is enforced)

There are no warnings. Either the program is correct, or it does not assemble.

---

## 3. Program entry and `.org`

### Entry point

### The implicit entry stub

The assembler always emits an implicit 3-byte entry stub at `0x0000`:

```text
0x0000: JMP <entry>
```

Because of this, `s8asm` forbids placing any user code/data below `0x0003`.

### Entry point selection

You may (optionally) mark an explicit entry point using `.org` with **no operand**:

```asm
.org
START:
    HALT
```

- If present, the entry address is the location counter at that `.org` line
- Only one entry marker `.org` (no operand) is allowed

If no entry marker exists, the entry address becomes the address of the *first*
`.org <addr>` in the program.

### Absolute origin

```asm
.org 0x0200
Data:
```

Defines absolute placement.

### Rules

- `.org <addr>` requires a **numeric literal** (labels are not allowed)
- `.org <addr>` must be `>= 0x0003` and `<= 0xFFFF`
- Overlapping writes → error
- Multiple entry markers `.org` (no operand) → error
- At least one `.org` (either form) must appear somewhere → error if missing

---

## 4. Includes

```asm
.include "kernel.s8"
.include "utils/math.s8"
```


- Paths are resolved relative to the including file
- Unlimited nesting depth
- Include cycles are detected and rejected
- **Multiple inclusion is forbidden**: the same include file may appear only once

Includes are textual and resolved before assembly.

---

## 5. Labels

- Case-sensitive
- Global namespace (across includes)
- May appear alone or on the same line

```asm
Loop:
    INC R0

Msg: .string "Hello"
```

Errors:
- Duplicate label → error
- Undefined label → error

---

## 6. Literals and syntax

### Numbers

- Decimal: `10`
- Hex: `0x0A`
- Binary: `0b00001010`

### Immediate values

Use `#`:

```asm
SET #0x41, R0
```

### Registers

General purpose registers:

- `R0`–`R7` (8-bit)

Special registers (16-bit; usable only with `PUSH`/`POP`):

- `IP` (instruction pointer)
- `SP` (stack pointer)
- `BP` (base/frame pointer)

### Whitespace

- Multiple spaces allowed
- One instruction per line

---

## 7. Data directives

### `.byte`

```asm
.byte 0x01, 2, 0b10101010

Notes:
- `.byte` accepts **numeric literals only** (labels are not allowed)
- Values must be `0..255`
```

### `.word`

16‑bit big-endian values:

```asm
.word 0x0200, START

Notes:
- `.word` accepts numeric literals or labels
- Values must be `0..65535`
```

### `.string`

```asm
Msg: .string "Hello\n"
```

- ASCII only
- Automatic `0x00` terminator
- Escapes supported: `\n`, `\r`, `\t`, `\0`, `\"`, `\\`, `\xNN` (two hex digits)

Non-ASCII → error.

---

## 8. Instruction set

### Data movement

| Instruction | Encoding | Description |
|------------|----------|-------------|
| SET #imm8, Rn | `04 imm reg` | `Rn = imm8` |
| LOAD addr16, Rn | `01 hi lo reg` | `Rn = mem[addr16]` |
| STORE Rn, addr16 | `02 reg hi lo` | `mem[addr16] = Rn` |
| LOADR Rdst, Rhi, Rlo | `1C dst hi lo` | `Rdst = mem[(Rhi<<8)|Rlo]` |
| STORER Rsrc, Rhi, Rlo | `03 src hi lo` | `mem[(Rhi<<8)|Rlo] = Rsrc` |

---

### Stack and calls

| Instruction | Encoding | Description |
|------------|----------|-------------|
| PUSH Rn | `10 reg` | Push an 8-bit register value |
| POP Rn | `11 reg` | Pop into an 8-bit register |
| PUSH IP/SP/BP | `10 reg` | Push 16-bit value as two bytes (big-endian) |
| POP IP/SP/BP | `11 reg` | Pop 16-bit value from two bytes (big-endian) |
| CALL addr16 | `12 hi lo` | Push return address (16-bit), jump to `addr16` |
| RET | `13` | Return to address popped from stack |

Stack notes:
- Stack grows downward in memory
- No overflow/underflow protection
- `CALL/RET` always use 16-bit return addresses

---

### Arithmetic and logic

| Instruction | Encoding | Description |
|------------|----------|-------------|
| ADD #imm8, Rn | `0E imm reg` | `Rn += imm8` (8-bit wrap), sets carry on overflow |
| ADDR Rsrc, Rdst | `0F src dst` | `Rdst += Rsrc` (8-bit wrap), sets carry on overflow |
| SUB #imm8, Rn | `14 imm reg` | `Rn -= imm8` (8-bit wrap), sets carry on borrow |
| SUBR Rsrc, Rdst | `15 src dst` | `Rdst -= Rsrc` (8-bit wrap), sets carry on borrow |
| INC Rn | `05 reg` | `Rn++`, sets carry if it wrapped from `0xFF` to `0x00` |
| DEC Rn | `06 reg` | `Rn--`, sets carry if it wrapped from `0x00` to `0xFF` |
| SHL #n, Rn | `1A n reg` | `Rn <<= n`, carry = last bit shifted out (per VM implementation) |
| SHR #n, Rn | `1B n reg` | `Rn >>= n`, carry = last bit shifted out (per VM implementation) |
| MUL #imm8, Rhi, Rlo | `16 imm rhi rlo` | 16-bit product; `Rlo=low`, `Rhi=high`, carry=1 if high!=0 |
| MULR Rsrc, Rhi, Rlo | `17 src rhi rlo` | 16-bit product; `Rlo=low`, `Rhi=high`, carry=1 if high!=0 |
| DIV #imm8, Rq, Rr | `18 imm rq rr` | `Rq=Rq/imm`, `Rr=Rq%imm` (beware overwrite), carry unchanged |
| DIVR Rsrc, Rq, Rr | `19 src rq rr` | `Rq=Rq/Rsrc`, `Rr=Rq%Rsrc` (beware overwrite), carry unchanged |

Notes:
- Division by 0 is undefined (host crash or VM stop).
- For `DIV/DIVR`, the VM computes quotient/remainder from the *original* value in `Rq`.
  If `Rq` and `Rr` are the same register, the remainder overwrites the quotient.

---

### Control flow

| Instruction | Encoding | Description |
|------------|----------|-------------|
| CMP Rn, #imm8 | `08 reg imm` | **Destructive compare**: `Rn -= imm8`; carry=1 if borrow (Rn < imm8) |
| CMPR Rn, Rm | `09 rn rm` | **Destructive compare**: `Rn -= Rm`; carry=1 if borrow (Rn < Rm) |
| JMP addr16 | `07 hi lo` | `IP = addr16` |
| JZ Rn, addr16 | `0A reg hi lo` | jump if `Rn == 0` |
| JNZ Rn, addr16 | `0B reg hi lo` | jump if `Rn != 0` |
| JC addr16 | `0C hi lo` | jump if carry flag `C == 1` |
| JNC addr16 | `0D hi lo` | jump if carry flag `C == 0` |
| NOP | `FF` | no operation |
| HALT | `00` | stop the VM |

Important:
- `CMP/CMPR` modify the compared register (they subtract). If you need a non-destructive compare,
  copy the value to a scratch register first.

---

## 9. Memory-mapped I/O (MMIO)

| Address | Name | Direction |
|--------:|------|-----------|
| 0xFF00 | KBD_STATUS | Read |
| 0xFF01 | KBD_DATA | Read |
| 0xFF02 | TTY_STATUS | Read |
| 0xFF03 | TTY_DATA | Write |

- Write a byte to `0xFF03` to output a character
- Keyboard behavior depends on host environment

---

## 10. `kernel.s8` (console kernel)

`kernel.s8` is an optional support library included via `.include`.

### Exported routines

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| PUTC | `R0` = char | — | `R3` | Waits for TTY ready, writes `R0` to `0xFF03` |
| GETC | — | `R0` = char | `R3` | Blocking key read |
| GETC_NB | — | `R0` = char or `0x00`, `R1` = 1/0 | `R3` | Non-blocking key read |
| PUTS | `R1:R2` = pointer | — | `R0`, `R3` | Print NUL-terminated string |

### Calling convention

- Arguments in registers
- No registers preserved (save what you need)
- Strings are ASCII and NUL-terminated

---

## 11. Standard libraries

These libraries are optional and are meant to be included explicitly.

### Overview

| Library | Depends on | Purpose |
|---|---|---|
| `kernel.s8` | — | Console MMIO primitives (`PUTC`, `GETC`, `PUTS`, etc.) |
| `mem.s8` | — | Byte-wise memory utilities (`memset/memcpy/memmove/memcmp/memchr`) |
| `str.s8` | — | Minimal NUL-terminated string helpers |
| `rng.s8` | — | 16-bit deterministic PRNG |
| `fmt.s8` | `kernel.s8` | Printing helpers (hex/dec) |
| `ctype.s8` | — | Character classification / case conversion (`isspace`, `isdigit`, …) |
| `u16.s8` | — | Unsigned 16-bit helpers (`add/sub/cmp/shifts/mul/div`) |
| `int16.s8` | — | Signed 16-bit helpers (`neg/abs/cmp`) |
| `conv.s8` | `ctype.s8`, `u16.s8`, `int16.s8`, `mem.s8` | String↔integer conversions (buffer-first formatting, checked parsing) |
| `line.s8` | `kernel.s8` | Line input (echo, NUL-terminated) |
| `parse.s8` | `ctype.s8` | Tokenization + checked `u8` decimal parsing |
| `stdio_console.s8` | `kernel.s8`, `line.s8` | Tiny `stdio`-like façade for console-only I/O |
| `cli.s8` | `kernel.s8`, `ctype.s8` | **Compatibility** wrappers (historical API; now mostly duplicates of `line.s8` + `parse.s8`) |
| `text.s8` | — | **Legacy/BASIC-oriented** text helpers (kept for older BASIC code) |
| `basic_helpers.s8` | varies | BASIC runtime helpers (may rely on BASIC globals; not a general-purpose lib) |

---

### `mem.s8`

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| MEMSET | `R1:R2` dst, `R0` value, `R3` len | — | `R3`, `R4` | Fill memory with a byte |
| MEMCPY | `R1:R2` dst, `R3:R4` src, `R5` len | — | `R0`, `R5` | Copy memory forward |
| MEMMOVE | `R1:R2` dst, `R3:R4` src, `R5` len | — | `R0`, `R5`, `R6`, `R7` | Copy memory, safe for overlap |
| MEMCMP | `R1:R2` a, `R3:R4` b, `R5` len | `R0` = `00`/`FF`/`01` | `R6`, `R7` | Compare ranges (lexicographic) |
| MEMCHR | `R1:R2` start, `R0` byte, `R3` len | `R1:R2` ptr, `R4` found | `R3`, `R5` | Find byte in bounded range |

### `str.s8`

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| STRLEN | `R1:R2` s | `R0` len | `R0`,`R3` | Compute length (advances pointer) |
| STREQ | `R1:R2` s1, `R3:R4` s2 | `R0` = 1/0 | `R0`,`R5`,`R6`,`R7` | String equality (advances pointers) |
| STRCPY | `R1:R2` dst, `R3:R4` src | — | `R5` | Copy NUL-terminated string |
| STRNCPY | `R1:R2` dst, `R3:R4` src, `R5` max (incl NUL) | — | `R5`,`R6` | Bounded copy (always NUL-terminate if `R5>0`) |
| STRCMP | `R1:R2` s1, `R3:R4` s2 | `R0` = `00`/`FF`/`01` | `R5`,`R6` | Lexicographic compare |
| STRCHR | `R1:R2` s, `R0` ch | `R1:R2` ptr, `R4` found | `R5` | Find character in string |

### `rng.s8`

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| RNG_NEXT16 | `R1:R2` -> seed (`[hi][lo]`) | `R6:R7` random; seed updated | `R0`,`R3`,`R4`,`R5` | `seed = seed*109 + 89 (mod 65536)`, returns `seed & 0x7FFF` |

### `kernel.s8`

Low-level console I/O via MMIO. See the MMIO section for addresses and behavior.

### `fmt.s8` (depends on `kernel.s8`)

Printing helpers (primarily for debugging / REPL output).

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| PUTHEX8 | `R0` value | — | `R0`,`R1`,`R2`,`R4`,`R5` (+kernel `R3`) | Print 2-digit uppercase hex |
| PUTHEX16 | `R1:R2` value | — | `R0`,`R1`,`R2`,`R4`,`R5`,`R7` (+kernel `R3`) | Print 4-digit uppercase hex |
| PUTDEC8 | `R0` value | — | `R0`,`R1`,`R2`,`R4` (+kernel `R3`) | Print unsigned 0..255 decimal |

### `ctype.s8`

Character classification / conversion helpers (ASCII only).

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| ISSPACE | `R0` ch | `R0`=1/0 | — | True for space/tab/CR/LF |
| ISDIGIT | `R0` ch | `R0`=1/0 | — | `'0'..'9'` |
| ISUPPER | `R0` ch | `R0`=1/0 | — | `'A'..'Z'` |
| ISLOWER | `R0` ch | `R0`=1/0 | — | `'a'..'z'` |
| ISALPHA | `R0` ch | `R0`=1/0 | — | letter |
| ISALNUM | `R0` ch | `R0`=1/0 | — | letter or digit |
| TOUPPER | `R0` ch | `R0` ch | — | Convert to uppercase if lowercase |
| TOLOWER | `R0` ch | `R0` ch | — | Convert to lowercase if uppercase |

### `u16.s8`

Unsigned 16-bit arithmetic helpers.

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| U16_ADD | `R0:R1` a, `R2:R3` b | `R0:R1` sum | `R4` | 16-bit add |
| U16_SUB | `R0:R1` a, `R2:R3` b | `R0:R1` diff | `R4` | 16-bit subtract |
| U16_CMP | `R0:R1` a, `R2:R3` b | `R0` = `FF/00/01` | `R4` | Compare (a<b, a==b, a>b) |
| U16_SHL1 | `R0:R1` x | `R0:R1` x<<1 | `R4` | Shift left by 1 |
| U16_SHR1 | `R0:R1` x | `R0:R1` x>>1 | `R4` | Shift right by 1 |
| U16_MUL_U8 | `R0:R1` a, `R2` b8 | `R0:R1` | `R3`,`R4`,`R5` | Multiply u16 by u8 |
| U16_DIV_U8 | `R0:R1` a, `R2` b8 | `R0:R1` quotient, `R3` remainder | `R4`,`R5`,`R6`,`R7` | Divide u16 by u8 |

### `int16.s8`

Signed 16-bit helpers (two's complement).

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| I16_NEG | `R0:R1` x | `R0:R1` -x | `R4` | Negate |
| I16_ABS | `R0:R1` x | `R0:R1` abs(x) | `R4` | Absolute value |
| I16_CMP | `R0:R1` a, `R2:R3` b | `R0`=`FF/00/01` | `R4`,`R5` | Signed compare |

### `conv.s8`

Conversions between integers and strings (buffer-first), plus checked parsing.

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| PARSE_U16_DEC | `R1:R2` ptr | `R0:R1` value; `R4` ok; `R1:R2` updated | `R3`,`R5` | Parse unsigned decimal (0..65535), no wrap |
| PARSE_I16_DEC | `R1:R2` ptr | `R0:R1` value; `R4` ok; `R1:R2` updated | many | Parse signed decimal (-32768..32767), no wrap |
| U16_TO_DEC_BUF | `R0:R1` value; `R2:R3` outbuf; `R4` outmax | `R0` len; `R4` ok | many | Convert u16 to decimal ASCII in buffer, NUL-terminated |

### `line.s8` (depends on `kernel.s8`)

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| READLINE_ECHO | `R1:R2` buf; `R3` max (incl NUL) | `R4` len | `R0`,`R3`,`R5`,`R6`,`R7` | Read line with echo and backspace editing |

### `parse.s8` (depends on `ctype.s8`)

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| SKIPSPACES | `R1:R2` ptr | `R1:R2` updated | `R0` | Skip spaces/tabs |
| READTOKEN | `R1:R2` src; `R3:R4` dst; `R5` max (incl NUL) | `R6` len; `R1:R2` updated | `R0`,`R5`,`R6`,`R7` | Read space/tab-delimited token |
| PARSE_U8_DEC | `R1:R2` ptr | `R0` value; `R4` ok; `R1:R2` updated | `R5`,`R6`,`R7` | Parse decimal 0..255 (checked), skips spaces/tabs |

### `stdio_console.s8` (console-only)

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| PUTCHAR | `R0` ch | — | `R0`,`R3` | Print single char |
| GETCHAR | — | `R0` ch | `R3` | Read single char (blocking) |
| FPUTS | `R1:R2` s | — | many | Print NUL-terminated string |
| FGETS | `R1:R2` buf; `R3` max (incl NUL) | `R4` len | many | Read line into buffer (wraps `READLINE_ECHO`) |

### `cli.s8` (compatibility)

`cli.s8` is retained for code that already includes it. Internally, its routines mirror `line.s8` and `parse.s8`.

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| READLINE_ECHO | `R1:R2` buf; `R3` max (incl NUL) | `R4` len | `R0`,`R3`,`R5`,`R6`,`R7` | Read line with echo + backspace |
| SKIPSPACES | `R1:R2` ptr | `R1:R2` updated | `R0` | Skip spaces/tabs |
| READTOKEN | `R1:R2` src; `R3:R4` dst; `R5` max (incl NUL) | `R6` len; `R1:R2` updated | `R0`,`R5`,`R6`,`R7` | Read token |
| PARSE_U8_DEC | `R1:R2` ptr | `R0` value; `R4` ok; `R1:R2` updated | `R5`,`R6`,`R7` | Checked u8 parse |

### `text.s8` (legacy/BASIC)

`text.s8` predates `ctype.s8`/`conv.s8` and is kept primarily for older Sophia BASIC code.
For new code, prefer `ctype.s8` + `parse.s8` + `conv.s8`.

| Routine | Args | Returns | Clobbers | Description |
|--------|------|---------|----------|-------------|
| SKIPSP | `R1:R2` ptr | `R1:R2` updated | `R0` | Skip ASCII spaces (0x20) |
| ISDIGIT | `R1:R2` ptr | `R0` = 1/0 | `R3` | Test whether `*ptr` is `'0'..'9'` |
| PARSE_UINT8 | `R1:R2` ptr | `R0` value; `R1:R2` updated | `R3`,`R4`,`R7` | Parse decimal unsigned number (**wraps mod 256**) |
| TOUPPER_Z | `R1:R2` ptr | — | `R0`,`R3` | Uppercase ASCII string in-place until NUL |
## 12. Example: Hello, Sophia!

```asm
.org 0x0800
.include "kernel.s8"

.org 0x0200
Msg: .string "Hello, Sophia!\n"

.org
START:
    SET #0x02, R1
    SET #0x00, R2
    CALL PUTS
    HALT
```

Assemble:
```bash
s8asm hello.s8 -o hello.bin
```

Run:
```bash
sophia8 hello.bin
```

---

## 13. Known limitations / sharp edges

- No memory protection
- No interrupts
- No stack safety
- No multitasking
- `CMP/CMPR` are destructive (they subtract)
- `MUL/MULR` encode destination registers as `(dst_high, dst_low)`
- `.byte` cannot use labels
- `.org` operands must be numeric literals (no labels)
- Include-once is enforced (multiple inclusion errors)
- IDE consoles may buffer input
- Behavior outside defined instructions is undefined but deterministic
- Many kernel / library routines clobber argument registers; save pointers/results you still need across calls (e.g. `PUTDEC8` clobbers `R1:R2`).

These limitations are **intentional**.

---

## 13. Design intent

Sophia8 exists to be *fully understandable*.

- No hidden behavior
- No magic
- No implicit state

If something feels manual, that is the point.

---

## 14. Debugging

Sophia8 debugging is intentionally simple and file-based.

### 14.1 Preprocessed source: `.pre.s8`

If you compile `prog.s8` to `prog.bin`, `s8asm` also writes `prog.pre.s8`.
This is the exact source that the assembler *actually saw* after expanding all `.include`s.

Practical uses:

- Confirm that includes expanded the way you expect (especially when includes are nested).
- Reproduce a build from a single file (share `*.pre.s8` when reporting an issue).
- Track down label collisions and layout mistakes caused by include order.

Each original line is preceded by an origin marker:

```asm
;@ path/to/file.s8:123
    SET #0x41, R0
```

### 14.2 Debug map: `.deb`

`prog.deb` is a text file emitted next to `prog.bin` that maps emitted bytes to source
locations. Each line includes:

- address (hex, 4 digits)
- length (decimal)
- kind (`CODE` or `DATA`)
- the exact bytes emitted
- `file:line: original source line`

This is what enables source-level breakpoints in the VM.

### 14.3 VM breakpoint workflow (file:line)

The VM understands `.deb` files directly:

```bash
# Run using debug map (loads the referenced .bin)
sophia8 prog.deb

# Stop when execution reaches a specific source location
sophia8 prog.deb path/to/file.s8 123
```

When a breakpoint is hit, the VM:

1. Prints `BREAK at <file>:<line> (0xADDR)`
2. Prints all registers (`R0..R7`, `IP`, `SP`, `BP`, `C`)
3. Saves a snapshot `debug.img` in the current directory
4. Stops execution

### 14.4 Resuming from a snapshot: `debug.img`

To resume after a breakpoint:

```bash
sophia8 debug.img
```

If you also provide `prog.deb` and a breakpoint, the VM can still resolve source locations:

```bash
sophia8 debug.img prog.deb path/to/file.s8 200
```

### 14.5 Practical tips

- Put your application code in one `.org` region and your data in another, and keep a small memory map comment at the top of the entry file.
- If something “mysteriously” changes after adding an `.include`, inspect the generated `*.pre.s8` first.
- If you can’t find a breakpoint location, check the `.deb` lines for the **exact** file path or filename used by the assembler.

### 14.6 Verbose execution logging: `-v`

For instruction-by-instruction debugging, the VM can produce an **append-only** trace log.

```bash
# Verbose trace using a .deb (also loads the referenced .bin)
sophia8 -v prog.deb

# Verbose trace for a raw .bin image (use .deb only for source mapping)
sophia8 -v --deb prog.deb prog.bin

# Verbose trace while resuming from a snapshot (use .deb only for source mapping)
sophia8 -v debug.img prog.deb
```

Rules:

- Verbose logging is enabled **only** when `-v` is present.
- When `-v` is used, a `.deb` debug map is **required** (either positional `prog.deb` or `--deb prog.deb`).
  - If no `.deb` is specified, the VM exits with: `No debug file specified`
- The VM writes to `verbose.log` in the current directory using **append mode** and **flushes after each executed instruction**
  (so partial logs survive process termination/timeouts).

Each executed instruction appends one log entry that includes:

- `file:line` resolved from the `.deb` for the current `IP` (when available)
- decoded instruction mnemonic + operands
- memory writes performed by the instruction (if any): address, old byte, new byte
- register dump: `R0..R7`, `IP`, `SP`, `BP`, `C`


Assembler lessons learned (design + debugging)
--------------------------------------------

- **Immediate vs address syntax**: Use '#' only for immediates. Bare numbers/labels are addresses. Mixing them is a common source of wrong encoding.
  - Example (good):

    ```
    LDI A, #0x2A   ; immediate
JMP loop        ; address via label
    ```
  - Example (bad):

    ```
    JMP #0x1000     ; '#' not allowed for addresses
    ```
- **.org semantics and entry mark**: .org with an operand moves the location counter. '.org' with no operand is treated as an entry-point marker (and may appear only once). The operand must be a numeric literal (labels not allowed).
  - Pitfall: Trying to write '.org start' or '.org #0x200' will fail by design.
  - Reason: Keeps entry-point explicit and avoids forward-reference ambiguity for the image layout.
- **Byte/word emission rules**: .byte accepts numeric literals only (no labels, no '#'). .word accepts numeric literals or labels (no '#'). Keep data widths explicit to avoid accidental truncation.
  - Pitfall: Using labels in .byte or using immediates in .word/.byte.
- **Comma splitting is simple**: Operands are split by commas without quote awareness. Keep string directives as a single quoted argument and avoid commas inside quoted strings unless the directive explicitly supports it.
  - Prevention: If you need commas in emitted bytes, use multiple .byte items rather than a single .string with commas.
- **Global labels and duplicate detection**: Labels are global and duplicates are a hard error. This prevents silent symbol capture across includes.
  - Prevention: Use a consistent prefixing convention per module (e.g., 'mem_', 'fmt_', 'cli_').
- **Include path resolution**: .include requires quotes and is resolved relative to the including file (with canonical/absolute handling). Keep includes acyclic; include stacks are reported on errors.
  - Pitfall: Forgetting quotes or relying on working-directory relative paths.
- **Overlap detection**: Any emitted byte overlap is a strict error. This catches accidental .org jumps into already-emitted regions early.
  - Prevention: Treat .org as a segment boundary and keep a simple memory map comment at the top of your entry file.
- **Two-pass assembly expectations**: Pass 1 builds layout and label addresses; pass 2 emits. Forward references are fine for instructions and .word, but not allowed where the assembler requires literal-only operands (e.g., .org operand, .byte).
  - Prevention: When in doubt, choose .word for label-bearing data and keep control directives literal.
- **Error reporting**: Preserve the original line (before comment stripping) for diagnostics, and report file/line plus include stack. Good errors reduce debugging time more than any other feature.
---

## 15. Graphics (C64-style cell renderer)

Sophia8 supports a simple **cell-based bitmap** display inspired by the Commodore 64:

- **Resolution:** 320×200
- **Cell grid:** 40×25 cells
- **Cell size:** 8×8 pixels
- **Per-cell colors:** 2 colors per cell (foreground/background), selected from a 16-color palette

### 15.1 VRAM layout (fixed base 0x8000)

Graphics memory is read from a **fixed base address**:

- **GFX_BASE:** `0x8000`
- **Total bytes:** `40 * 25 * 9 = 9000`
- **Address range:** `0x8000 .. 0xA327` (inclusive)

Each cell consumes **9 bytes**:

- `byte[0..7]`: 8 bitmap rows (MSB = leftmost pixel)
  - bit `1` → foreground
  - bit `0` → background
- `byte[8]`: color byte
  - high nibble (bits 7..4) → **foreground color index** `0..15`
  - low nibble  (bits 3..0) → **background color index** `0..15`

Cell ordering is row-major:

- `cell_index = cy*40 + cx`
- `cell_addr  = 0x8000 + cell_index*9`

### 15.2 VM usage

Enable graphics rendering when running a raw image:

```bash
sophia8 program.bin --gfx
```

Optional output filename (default is `frame.ppm`):

```bash
sophia8 program.bin --gfx --gfx-out frame.ppm
```

Rendering behavior:

- While the VM runs, the renderer refreshes **best-effort ~60 Hz**
- When the VM stops (`HALT`), the VM always writes a **final frame**

Current backend writes a binary **PPM (P6)** file (dependency-free).

### 15.3 Producing graphics from assembly

A typical “image viewer” style program places graphics data at `.org 0x8000`
and halts:

```asm
.org 0x0200
START:
    HALT

.org 0x8000
GFX_DATA:
    ; 9000 bytes total (40*25 cells * 9 bytes per cell)
    ; .byte ...
```

### 15.4 Tooling (optional, external)

Common helper scripts used during development:

- `img_to_s8gfx.py`: converts an input image into a `.s8` file that emits VRAM bytes at `.org 0x8000`
- `ppm_to_png.py`: converts a PPM (P6/P3) file (e.g., `frame.ppm`) into PNG (requires Pillow)

